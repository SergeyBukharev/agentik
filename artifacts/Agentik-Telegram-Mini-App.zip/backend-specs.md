# Backend-контракты Agentik

Фронтенд получает адрес API из `VITE_API_URL`, в локальном Vite используется тот же origin. Для проверки запустите `npm run dev` или отдельно `npm run server`. Используйте тестовую пару из серверного `.env`.

## Чат в Telegram

Сборка Telegram использует `server.mjs` из архива. В ней `/api/telegram/shares?source=chat:<id>` и `/api/telegram/shares?source=room:<id>` требуют Bearer-сессию из `/api/access/login`. Состояние определяется аккаунтом и идентификатором чата.

| Метод и путь | Вход и выход |
| --- | --- |
| `GET /api/telegram/shares?source=…` | Возвращает `{share: null}` или `{share: {id, url, expiresAt}}`. |
| `PUT /api/telegram/shares?source=…` | Принимает `{title, messages}`. У сообщения есть `author`, `text`, `role` и необязательный `hasImage`. До 50 сообщений. Ответ `{share: {id, url, expiresAt}}`. Предыдущая ссылка отзывается. |
| `DELETE /api/telegram/shares?source=…` | Отзывает ссылку текущего аккаунта, ответ 204. |
| `GET /api/telegram/shares/<id>` | По действующему идентификатору возвращает `{title, messages, expiresAt}`. Ответ 404 для отозванной, истёкшей или неизвестной ссылки. |

`expiresAt` задаётся в миллисекундах Unix. Срок ссылки 24 часа. Ответы копий отправляются с `Cache-Control: no-store`. Каталог `TELEGRAM_SHARE_DIR` расположен вне статики. Разрешённый origin задаёт `ALLOWED_ORIGIN`. `tgWebAppStartParam` открывает нужную копию. Вход владельца проверяет код Agentik. [Telegram Mini Apps](https://core.telegram.org/bots/webapps#direct-link-mini-apps)

## Работающие маршруты

| Метод и путь | Запрос и ответ |
| --- | --- |
| `POST /api/access/login` | JSON `{ "email": "owner@example.test", "code": "TEST42" }`. Возвращает `{accountId,token,expiresAt,plan?}`. Коды из старого списка без привязки принимаются в формате `{code}`. Сервер хранит пару в `AGENTIK_ACCOUNT_EMAIL` и `AGENTIK_ACCOUNT_CODE`, выделяет PRO через `AGENTIK_PRO_CODES`. |
| `GET /api/access/session` | `Authorization: Bearer <token>`. Возвращает `{accountId,expiresAt,plan?}` либо `401`. Срок сессии 90 дней, `expiresAt` в миллисекундах Unix. |
| `POST /api/chat` | Bearer и JSON `{assistant:{name,instruction}, messages:[{role,content}], model?, language?}`. Модели `auto`, `chatgpt`, `deepseek`, `alice`, языки `ru` и `en`. Ответ `{reply}`. До 20 сообщений, до 6000 символов в сообщении, последнее от пользователя, тело до 65 536 байт. |
| `POST /api/chat?media=1` | Та же схема и одно поле `images:[{id,name,url}]` в последнем сообщении. `url` содержит компактный raster data URL. До 320 000 символов URL и 400 000 байт на запрос. Сервер передаёт изображение только модели с поддержкой зрения. Изображение передаётся вместе с текущим сообщением; в дальнейших запросах сохраняется текстовый контекст. |

JSON-ошибка имеет поле `error`. Формат `400`, отказ доступа `401/403`, размер `413`, несовместимая модель для изображения `422`, лимит `429`, недоступная модель `503`, сбой поставщика `502`. Для входа `429` содержит `Retry-After`. Ответы API имеют `Cache-Control: no-store`. CORS использует точный `ALLOWED_ORIGIN`.

Модели настраиваются `AI_API_KEY`, `AI_MODEL`, `AI_API_BASE` для авто, `AI_OPENAI_API_KEY` и `AI_OPENAI_MODEL` для ChatGPT, `AI_DEEPSEEK_API_KEY` и `AI_DEEPSEEK_MODEL` для DeepSeek. `AI_VISION=true` явно включает изображения для модели авто. Диктовка производит текст в браузере, отдельный аудиоэндпоинт для этого сценария не нужен.

Для Алисы AI задайте на сервере `AI_ALICE_API_KEY` и `AI_ALICE_FOLDER_ID`. Agentik формирует URI `gpt://<каталог>/aliceai-llm`. Выбрать другое имя текстовой модели можно через `AI_ALICE_MODEL`, например `aliceai-llm-flash`. Интеграция принимает текстовые сообщения. [Модели Yandex AI Studio](https://aistudio.yandex.ru/ru/docs/ai-studio/concepts/generation/models) · [Completions API](https://aistudio.yandex.ru/ru/docs/ai-studio/operations/generation/completions-basic)

## Группы и PRO для серверной реализации

Сейчас группы и пробный баланс сообщений работают на клиенте в одном браузере. Free получает 2 демотокена на аккаунт, принятая отправка стоит 1. PRO включает отправку. Связь с платёжной системой задаётся отдельно. Для обмена между устройствами подключите следующие операции к общей БД с проверкой Bearer.

| Предлагаемая операция | Условия |
| --- | --- |
| `POST /api/conversations` | Создание чата доступно до отправки сообщения. Повтор запроса с тем же `clientId` возвращает созданный чат. |
| `POST /api/conversations/{id}/invite` | Владелец открывает доселе приватный чат, создаёт отзывное приглашение со сроком действия. |
| `POST /api/invites/{token}/join` | Проверяет токен, срок и статус группы. Повторное вступление возвращает текущего участника. |
| `GET/POST /api/conversations/{id}/messages` | Требует членства. Для POST транзакционно записать сообщение и списать пробный токен при наличии баланса. Повтор с тем же `clientMessageId` возвращает сохранённый результат без повторного списания. Второе сообщение принимается с нулевым итоговым балансом, а следующая отправка Free получает `402` и `code: "PRO_REQUIRED"`. GET возвращает курсор. Для уведомлений подойдёт подписка с повторным подтверждением членства. |
| `PATCH /api/conversations/{id}/visibility` | Только владелец. `{visibility:"private"}` одновременно отзывает приглашения и удаляет остальных участников. Владелец сохраняет историю. |

Проверка PRO после оплаты должна опираться на подписанный сервером статус. Клиентский `VITE_PRO_CHECKOUT_URL` задаёт адрес перехода к оплате. Для медиа общего чата добавьте авторизованные загрузки и удаление доступа одновременно с отзывом членства.

## MCP для агента разработчика

Пример конфигурации MCP-клиента после `npm ci`:

```json
{"mcpServers":{"agentik-files":{"command":"node","args":["D:/Agentik/scripts/mcp-files.mjs"]}}}
```

Транспорт stdio. `list_project_files` возвращает разрешённые пути, `read_project_file` читает выбранный файл. Список задан в исходнике и включает документацию и общие контракты. Доступ работает локально в процессе агента. Секреты, историю пользователя и системные каталоги MCP не открывает.
