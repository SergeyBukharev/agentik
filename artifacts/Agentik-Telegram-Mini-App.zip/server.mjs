import { createServer } from "node:http";
import { createReadStream, readFileSync, statSync } from "node:fs";
import { mkdir, open, readFile, realpath, rename, rm, stat } from "node:fs/promises";
import { extname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { Readable } from "node:stream";
import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { setTimeout } from "node:timers/promises";
// src/access-contract.ts
var ACCESS_DURATION_MS = 7776e6;
function normalizeAccessCode(value) {
	if (typeof value !== "string" || value.length > 32) return null;
	const code = value.replace(/[\s-]/g, "");
	return /^[a-z0-9]{6}$/i.test(code) ? code.toUpperCase() : null;
}
function isAccessSession(value, now = Date.now()) {
	if (!value || typeof value !== "object") return false;
	const { accountId, token, expiresAt, plan, offerPro } = value;
	return typeof accountId === "string" && /^[a-f0-9]{32}$/.test(accountId) && (plan === void 0 || plan === "pro") && (offerPro === void 0 || plan === void 0 && offerPro === true) && typeof token === "string" && token.length < 512 && /^v1\.[\w-]+\.[\w-]{43}$/.test(token) && typeof expiresAt === "number" && Number.isSafeInteger(expiresAt) && expiresAt > now && expiresAt <= now + 7776e6 + 6e4;
}
// server/access.ts
var WINDOW_MS = 3e5;
var MAX_BODY = 1024;
function parseCodes(text) {
	const codes = text.replace(/^\uFEFF/, "").split(/\r?\n/).map((line) => line.trim()).filter((line) => line && !line.startsWith("#")).map((line) => {
		return normalizeAccessCode(/^\[([a-z0-9]{6})\](?:\[[^\]]*\])?$/i.exec(line)?.[1] ?? line);
	});
	return codes.some((code) => code === null) ? [] : [...new Set(codes)];
}
function parseClientAccounts(text) {
	const accounts = /* @__PURE__ */ new Map();
	if (!text?.trim()) return accounts;
	try {
		const entries = JSON.parse(text);
		if (!Array.isArray(entries)) return accounts;
		for (const entry of entries) {
			const code = normalizeAccessCode(entry?.code);
			const email = typeof entry?.email === "string" ? entry.email.trim().toLowerCase() : "";
			if (!code || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || accounts.has(code)) return /* @__PURE__ */ new Map();
			accounts.set(code, email);
		}
		return accounts;
	} catch {
		return /* @__PURE__ */ new Map();
	}
}
var BodyTooLarge = class extends Error {};
async function readCredentials(request) {
	if (Number(request.headers.get("Content-Length")) > MAX_BODY) throw new BodyTooLarge();
	const reader = request.body?.getReader();
	if (!reader) return null;
	const bytes = new Uint8Array(MAX_BODY);
	let length = 0;
	try {
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			if (length + value.byteLength > MAX_BODY) throw new BodyTooLarge();
			bytes.set(value, length);
			length += value.byteLength;
		}
		const data = JSON.parse(new TextDecoder().decode(bytes.subarray(0, length)));
		if (!data || typeof data !== "object" || !("code" in data)) return null;
		const code = normalizeAccessCode(data.code);
		const email = "email" in data ? data.email : "";
		if (!code || typeof email !== "string" || email.length > 254) return null;
		return {
			code,
			email: email.trim().toLowerCase()
		};
	} finally {
		reader.releaseLock();
	}
}
function createAccess(config) {
	const now = config.now ?? Date.now;
	const secret = config.secret ?? "";
	const accountId = (code) => createHmac("sha256", secret).update("account:" + code).digest("hex").slice(0, 32);
	const signature = (payload) => createHmac("sha256", secret).update(payload).digest();
	const accounts = new Set(secret.length >= 32 ? parseCodes(config.codesText ?? "").map(accountId) : []);
	const bindings = /* @__PURE__ */ new Map();
	function bind(id, email, aliases = []) {
		if (secret.length < 32 || !email) return;
		accounts.add(id);
		bindings.set(id, {
			emails: /* @__PURE__ */ new Set([email, ...aliases]),
			stamp: signature("paired-login:" + email).toString("base64url")
		});
	}
	const pairedCode = normalizeAccessCode(config.accountCode);
	const pairedEmail = config.accountEmail?.trim().toLowerCase() ?? "";
	const pairedId = pairedCode ? accountId(pairedCode) : void 0;
	if (pairedId) {
		accounts.delete(pairedId);
		bind(pairedId, pairedEmail, (config.accountEmailAliases ?? "").split(",").map((email) => email.trim().toLowerCase()).filter(Boolean));
	}
	for (const [code, email] of parseClientAccounts(config.clientAccounts)) {
		const id = accountId(code);
		if (id !== pairedId) bind(id, email);
	}
	const proAccounts = new Set((config.proCodes ?? "").split(",").map(normalizeAccessCode).filter((item) => !!item).map(accountId));
	const entitlements = (id) => {
		if (proAccounts.has(id)) return { plan: "pro" };
		return id === pairedId ? { offerPro: true } : {};
	};
	const ready = accounts.size > 0;
	const failures = /* @__PURE__ */ new Map();
	let globalFailures = {
		until: 0,
		count: 0
	};
	function verify(token) {
		if (!ready || !token || token.length >= 512 || !/^v1\.[\w-]+\.[\w-]{43}$/.test(token)) return null;
		const [version, encoded, presented] = token.split(".");
		const signedPayload = version + "." + encoded;
		const presentedBytes = Buffer.from(presented, "base64url");
		if (presentedBytes.toString("base64url") !== presented || !timingSafeEqual(signature(signedPayload), presentedBytes)) return null;
		try {
			const decoded = JSON.parse(Buffer.from(encoded, "base64url").toString("utf8"));
			if (decoded.binding !== bindings.get(decoded.accountId)?.stamp) return null;
			const session = {
				accountId: decoded.accountId,
				expiresAt: decoded.expiresAt,
				token,
				...entitlements(decoded.accountId)
			};
			return isAccessSession(session, now()) && accounts.has(session.accountId) ? session : null;
		} catch {
			return null;
		}
	}
	function issue(id) {
		const expiresAt = now() + ACCESS_DURATION_MS;
		const payload = "v1." + Buffer.from(JSON.stringify({
			accountId: id,
			expiresAt,
			binding: bindings.get(id)?.stamp
		})).toString("base64url");
		return {
			accountId: id,
			expiresAt,
			...entitlements(id),
			token: payload + "." + signature(payload).toString("base64url")
		};
	}
	async function respond(request, path, client, headers) {
		const out = (status, data, extra = {}) => Response.json(data, {
			status,
			headers: {
				...headers,
				...extra
			}
		});
		if (!ready) return out(503, { error: "Проверка кодов сейчас недоступна." });
		if (path === "/api/access/session") {
			if (request.method !== "GET") return out(405, { error: "Используйте GET." });
			const verified = verify(request.headers.get("Authorization")?.match(/^Bearer (\S+)$/)?.[1]);
			return verified ? out(200, {
				accountId: verified.accountId,
				expiresAt: verified.expiresAt,
				...entitlements(verified.accountId)
			}) : out(401, { error: "Срок входа истёк. Введите код ещё раз." });
		}
		if (path !== "/api/access/login") return out(404, { error: "Не найдено." });
		if (request.method !== "POST") return out(405, { error: "Используйте POST." });
		if (request.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() !== "application/json") return out(415, { error: "Ожидается JSON." });
		let credentials;
		try {
			credentials = await readCredentials(request);
		} catch (error) {
			return error instanceof BodyTooLarge ? out(413, { error: "Запрос слишком большой." }) : out(400, { error: "Некорректный запрос." });
		}
		if (!credentials) return out(400, { error: "Введите шесть латинских букв или цифр." });
		const time = now();
		if (globalFailures.until <= time) {
			globalFailures = {
				until: time + WINDOW_MS,
				count: 0
			};
			for (const [ip, entry] of failures) if (entry.until <= time) failures.delete(ip);
		}
		const record = failures.get(client);
		const attempts = record && record.until > time ? record : {
			until: time + WINDOW_MS,
			count: 0
		};
		if (attempts.count >= 6 || globalFailures.count >= 100) {
			const deadline = Math.max(attempts.count >= 6 ? attempts.until : 0, globalFailures.count >= 100 ? globalFailures.until : 0);
			return out(429, { error: "Слишком много попыток." }, { "Retry-After": String(Math.ceil((deadline - time) / 1e3)) });
		}
		const id = accountId(credentials.code);
		const binding = bindings.get(id);
		if (accounts.has(id) && (!binding || binding.emails.has(credentials.email))) return out(200, issue(id));
		attempts.count++;
		failures.set(client, attempts);
		globalFailures.count++;
		return out(401, { error: "Код не подошёл. Проверьте символы и повторите." });
	}
	return {
		ready,
		respond,
		verify
	};
}
// src/chat-media.ts
var CHAT_MODELS = [
	"auto",
	"chatgpt",
	"deepseek",
	"alice"
];
function isChatModel(value) {
	return CHAT_MODELS.some((item) => item === value);
}
function isChatImage(value) {
	if (!value || typeof value !== "object") return false;
	const { id, name, url } = value;
	return typeof id === "string" && id.length <= 100 && typeof name === "string" && name.length <= 120 && typeof url === "string" && url.length <= 32e4 && /^data:image\/(jpeg|png|webp);base64,[a-z0-9+/]+=*$/i.test(url);
}
// src/chat-contract.ts
var MAX_MEDIA_CHAT_BODY_BYTES = 4e5;
var MAX_CHAT_BODY_BYTES = 65536;
var MAX_CHAT_MESSAGE_LENGTH = 6e3;
function isChatDocument(value) {
	if (!value || typeof value !== "object") return false;
	const { id, name, text, truncated } = value;
	return typeof id === "string" && !!id && id.length <= 128 && typeof name === "string" && !!name.trim() && name.length <= 160 && typeof text === "string" && !!text.trim() && text.length <= 4e3 && (truncated === void 0 || truncated === true);
}
// src/telegram-share-contract.ts
var TELEGRAM_SHARE_PREFIX = "/api/telegram/shares";
var TELEGRAM_SHARE_PAGE_PREFIX = "/agentik/share";
var TELEGRAM_SHARE_PREVIEW_WIDTH = 1200;
var MAX_TELEGRAM_SHARE_TEXT_LENGTH = MAX_CHAT_MESSAGE_LENGTH;
function isTelegramShareId(value) {
	return typeof value === "string" && value.length === 59 && /^s_[a-f0-9]{32}_[A-Za-z0-9_-]{24}$/.test(value);
}
// server/app.ts
function isChatTurn(value, media) {
	if (!value || typeof value !== "object") return false;
	const { role, content, images, document } = value;
	return (role === "user" || role === "assistant") && typeof content === "string" && content.length <= 6e3 && (!!content.trim() || !!images?.length) && (images === void 0 || media && role === "user" && Array.isArray(images) && images.length === 1 && images.every(isChatImage)) && (document === void 0 || role === "user" && !!content.trim() && isChatDocument(document));
}
function textWithDocument(message, english) {
	const { content, document } = message;
	if (!document) return content;
	return `${content}\n\n${document.truncated ? english ? "File excerpt" : "Фрагмент файла" : english ? "Attached file" : "Прикреплённый файл"} — ${document.name}\n${document.text}${document.truncated ? "\n[…]" : ""}`;
}
function createHandler(config) {
	const fetcher = config.fetcher ?? fetch;
	const hits = /* @__PURE__ */ new Map();
	const access = config.access ? createAccess(config.access) : null;
	const origins = new Set(config.origins ?? (config.origin ? [config.origin] : []));
	return async (req, clientAddress = "unknown") => {
		const headers = {
			"Cache-Control": "no-store",
			"X-Content-Type-Options": "nosniff",
			"Vary": "Origin"
		};
		const out = (status, data) => Response.json(data, {
			status,
			headers
		});
		const origin = req.headers.get("Origin");
		if (origin && !origins.has(origin)) return out(403, { error: "Источник запроса не разрешён." });
		if (origin) {
			headers["Access-Control-Allow-Origin"] = origin;
			headers["Access-Control-Expose-Headers"] = "Retry-After";
		}
		const url = new URL(req.url);
		const path = url.pathname;
		const telegramOwnerRoute = path === TELEGRAM_SHARE_PREFIX;
		const telegramRoute = config.telegramShares && (telegramOwnerRoute || path.startsWith(`/api/telegram/shares/`));
		if (req.method === "OPTIONS") {
			const methods = telegramRoute ? telegramOwnerRoute ? "GET, PUT, DELETE, OPTIONS" : "GET, OPTIONS" : "GET, POST, OPTIONS";
			return new Response(null, {
				status: 204,
				headers: {
					...headers,
					"Access-Control-Allow-Methods": methods,
					"Access-Control-Allow-Headers": "Authorization, Content-Type"
				}
			});
		}
		if (path.startsWith("/api/access/") && access) return access.respond(req, path, clientAddress, headers);
		const telegramPreviewRoute = path.startsWith(TELEGRAM_SHARE_PAGE_PREFIX + "/");
		if ((telegramRoute || telegramPreviewRoute) && config.telegramShares) {
			const token = telegramOwnerRoute ? req.headers.get("Authorization")?.match(/^Bearer (\S+)$/)?.[1] : void 0;
			return config.telegramShares(req, token ? access?.verify(token) ?? null : null, headers);
		}
		if (path !== "/api/chat") return out(404, { error: "Не найдено." });
		if (req.method !== "POST") return out(405, { error: "Используйте POST." });
		const token = req.headers.get("Authorization")?.match(/^Bearer (\S+)$/)?.[1];
		if (!token) return out(401, { error: "Войдите по коду доступа." });
		let identity = "local";
		if (access) {
			const verified = access.verify(token);
			if (!verified) return out(401, { error: "Срок входа истёк. Введите код ещё раз." });
			identity = verified.accountId;
		} else if (config.supabaseUrl && config.supabaseKey) try {
			const auth = await fetcher(`${config.supabaseUrl}/auth/v1/user`, {
				headers: {
					apikey: config.supabaseKey,
					Authorization: `Bearer ${token}`
				},
				signal: AbortSignal.timeout(5e3)
			});
			if (!auth.ok) return out(401, { error: "Сессия истекла. Войдите снова." });
			const user = await auth.json();
			if (typeof user.id !== "string") return out(401, { error: "Недействительная сессия." });
			identity = user.id;
		} catch {
			return out(503, { error: "Сервис входа временно недоступен." });
		}
		else if (!config.localToken || token !== config.localToken) return out(401, { error: "Недействительный токен API." });
		const media = url.searchParams.get("media") === "1";
		const maxBytes = media ? MAX_MEDIA_CHAT_BODY_BYTES : MAX_CHAT_BODY_BYTES;
		let payload;
		try {
			const reader = req.body?.getReader();
			let size = 0;
			const chunks = [];
			if (reader) for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				size += value.byteLength;
				if (size > maxBytes) {
					await reader.cancel();
					return out(413, { error: "Запрос слишком большой." });
				}
				chunks.push(value);
			}
			const bytes = new Uint8Array(size);
			let offset = 0;
			for (const c of chunks) {
				bytes.set(c, offset);
				offset += c.length;
			}
			payload = JSON.parse(new TextDecoder().decode(bytes));
		} catch {
			return out(400, { error: "Некорректный JSON." });
		}
		if (!payload?.assistant || typeof payload.assistant.instruction !== "string" || payload.assistant.instruction.length > 4e3 || !payload.assistant.instruction.trim() || !Array.isArray(payload.messages) || !payload.messages.length || payload.messages.length > 20 || !payload.messages.every((message) => isChatTurn(message, media)) || payload.messages.at(-1).role !== "user") return out(400, { error: "Проверьте сообщения: до 6000 символов каждое, не более 20 сообщений." });
		const choice = payload.model ?? "auto";
		if (!isChatModel(choice)) return out(400, { error: "Неизвестная модель." });
		const messages = payload.messages;
		const images = messages.flatMap((message) => message.images ?? []);
		if (media && images.length !== 1) return out(400, { error: "Прикрепите одно изображение." });
		const candidates = [
			config,
			config.providers?.chatgpt,
			config.providers?.deepseek,
			config.providers?.alice
		].filter((item) => !!item?.apiKey && !!item.model);
		const provider = choice === "auto" ? candidates.find((item) => !images.length || item.vision) ?? candidates[0] : config.providers?.[choice];
		if (!provider?.apiKey || !provider.model) return out(503, { error: "Выбранная модель ещё не настроена. Используйте другую модель или деморежим." });
		if (images.length && !provider.vision) return out(422, { error: "Эта модель принимает только текст. Для изображения выберите модель с поддержкой изображений." });
		const english = payload.language === "en";
		const providerMessages = messages.map((message) => {
			const text = textWithDocument(message, english);
			return {
				role: message.role,
				content: message.images?.length ? [{
					type: "text",
					text: text || (english ? "Describe the image." : "Опиши изображение.")
				}, ...message.images.map((image) => ({
					type: "image_url",
					image_url: { url: image.url }
				}))] : text
			};
		});
		const system = payload.language === "en" ? payload.assistant.instruction + " Respond in English unless requested otherwise." : payload.assistant.instruction;
		const now = Date.now();
		for (const [k, v] of hits) if (now - v.start > 6e4) hits.delete(k);
		if (hits.size >= 1e4 && !hits.has(identity)) return out(429, { error: "Сервис занят. Повторите позже." });
		const hit = hits.get(identity) ?? {
			count: 0,
			start: now
		};
		if (hit.count >= 20) return out(429, { error: "Лимит запросов: повторите через минуту." });
		hit.count++;
		hits.set(identity, hit);
		try {
			const upstreamHeaders = {
				Authorization: `${provider.authScheme ?? "Bearer"} ${provider.apiKey}`,
				"Content-Type": "application/json"
			};
			if (provider.project) upstreamHeaders["OpenAI-Project"] = provider.project;
			const response = await fetcher(`${(provider.apiBase ?? "https://api.openai.com/v1").replace(/\/$/, "")}/chat/completions`, {
				method: "POST",
				headers: upstreamHeaders,
				body: JSON.stringify({
					model: provider.model,
					messages: [{
						role: "system",
						content: system
					}, ...providerMessages],
					max_tokens: 1200
				}),
				signal: AbortSignal.timeout(3e4)
			});
			if (!response.ok) return out(502, { error: "AI временно не отвечает. Попробуйте ещё раз." });
			const reply = (await response.json())?.choices?.[0]?.message?.content;
			if (typeof reply !== "string" || !reply.trim()) return out(502, { error: "Получен пустой ответ AI. Повторите запрос." });
			return out(200, { reply });
		} catch {
			return out(502, { error: "Не удалось связаться с AI. Повторите запрос." });
		}
	};
}
// server/runtime.ts
function readCodeFile(path) {
	try {
		const stat = statSync(path);
		if (!stat.isFile() || stat.size > 262144) return void 0;
		return readFileSync(path, "utf8");
	} catch {
		return;
	}
}
function createRuntime(env, loopbackPort, telegramShares) {
	const origins = (env.ALLOWED_ORIGIN ?? "").split(",").map((value) => value.trim()).filter(Boolean);
	const aliceFolder = env.AI_ALICE_FOLDER_ID?.trim();
	if (loopbackPort) origins.push(`http://127.0.0.1:${loopbackPort}`, `http://localhost:${loopbackPort}`, `http://[::1]:${loopbackPort}`);
	return createHandler({
		origins,
		telegramShares,
		apiKey: env.AI_API_KEY,
		apiBase: env.AI_API_BASE,
		model: env.AI_MODEL,
		vision: env.AI_VISION === "true",
		providers: {
			chatgpt: {
				apiKey: env.AI_OPENAI_API_KEY,
				model: env.AI_OPENAI_MODEL,
				apiBase: env.AI_OPENAI_BASE ?? "https://api.openai.com/v1",
				vision: true
			},
			deepseek: {
				apiKey: env.AI_DEEPSEEK_API_KEY,
				model: env.AI_DEEPSEEK_MODEL,
				apiBase: env.AI_DEEPSEEK_BASE ?? "https://api.deepseek.com/v1"
			},
			alice: {
				apiKey: env.AI_ALICE_API_KEY,
				apiBase: env.AI_ALICE_API_BASE ?? "https://ai.api.cloud.yandex.net/v1",
				model: aliceFolder ? `gpt://${aliceFolder}/${env.AI_ALICE_MODEL?.trim() || "aliceai-llm"}` : void 0,
				authScheme: "Api-Key",
				project: aliceFolder
			}
		},
		access: {
			codesText: readCodeFile(resolve(env.AGENTIK_CODES_FILE || "codes-for-pro.txt")),
			secret: env.AGENTIK_ACCESS_SECRET,
			accountEmail: env.AGENTIK_ACCOUNT_EMAIL,
			accountEmailAliases: env.AGENTIK_ACCOUNT_EMAIL_ALIASES,
			accountCode: env.AGENTIK_ACCOUNT_CODE,
			clientAccounts: env.AGENTIK_CLIENT_ACCOUNTS,
			proCodes: env.AGENTIK_PRO_CODES
		}
	});
}
function nodeApi(handler) {
	return async (req, res, next) => {
		if (next && !req.url?.startsWith("/api/")) return next();
		try {
			const method = req.method ?? "GET";
			const hasBody = method !== "GET" && method !== "HEAD";
			const response = await handler(new Request(`http://localhost${req.url}`, {
				method,
				headers: req.headers,
				...hasBody ? {
					body: Readable.toWeb(req),
					duplex: "half"
				} : {}
			}), req.socket.remoteAddress);
			res.writeHead(response.status, Object.fromEntries(response.headers));
			res.end(Buffer.from(await response.arrayBuffer()));
		} catch {
			if (res.headersSent) return res.end();
			res.writeHead(500, {
				"Content-Type": "application/json",
				"Cache-Control": "no-store"
			});
			res.end(JSON.stringify({ error: "Не удалось обработать запрос." }));
		}
	};
}
// server/telegram-share-preview.ts
var pngSignature = Buffer.from("89504e470d0a1a0a", "hex");
function parseSharePreviewPng(value) {
	if (typeof value !== "string" || value.length > Math.ceil(65536) * 4 || value.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(value)) return;
	const bytes = Buffer.from(value, "base64");
	if (bytes.length < 45 || bytes.length > 196608 || !bytes.subarray(0, 8).equals(pngSignature) || bytes.readUInt32BE(8) !== 13 || bytes.toString("ascii", 12, 16) !== "IHDR" || bytes.readUInt32BE(16) !== 1200 || bytes.readUInt32BE(20) !== 630) return;
	return value;
}
function httpsShareOrigin(value) {
	if (!value) return;
	try {
		const url = new URL(value);
		if (url.protocol === "https:" && url.pathname === "/" && !url.username && !url.password && !url.search && !url.hash) return url.origin;
	} catch {}
}
function escapeHtml(text) {
	return text.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
function respondToSharePreview({ method, headers, title, id, publicOrigin, previewPng, image }) {
	if (image) {
		if (!previewPng) return new Response(null, {
			status: 302,
			headers: {
				...headers,
				Location: publicOrigin + "/agentik/brand/agentik-og.png"
			}
		});
		const bytes = Uint8Array.from(Buffer.from(previewPng, "base64"));
		return new Response(method === "HEAD" ? null : bytes, { headers: {
			...headers,
			"Content-Type": "image/png",
			"Content-Length": String(bytes.length)
		} });
	}
	const previewUrl = escapeHtml(publicOrigin + TELEGRAM_SHARE_PAGE_PREFIX + "/" + id);
	const safeTitle = escapeHtml(title);
	const imageUrl = previewUrl + "/preview.png";
	const html = `<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${safeTitle} · Agentik</title>
<meta property="og:type" content="website">
<meta property="og:site_name" content="Agentik">
<meta property="og:title" content="${safeTitle}">
<meta property="og:description" content="Копия чата в Agentik">
<meta property="og:url" content="${previewUrl}">
<meta property="og:image" content="${imageUrl}">
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="${TELEGRAM_SHARE_PREVIEW_WIDTH}">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Agentik · ${safeTitle}">
<meta name="twitter:card" content="summary_large_image">
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100svh;display:grid;place-items:center;padding:24px;background:#fcfdfb;color:#242822;font:16px system-ui,sans-serif}
main{width:min(100%,680px);text-align:center}
img{display:block;width:100%;height:auto}
h1{font-size:clamp(24px,5vw,36px);overflow-wrap:anywhere}
a{display:inline-flex;align-items:center;min-height:44px;padding:0 18px;border-radius:10px;background:#d4f58a;color:#242822;font-weight:650}
</style>
</head>
<body><main>
<img src="${imageUrl}" width="1200" height="630" alt="Agentik">
<h1>${safeTitle}</h1>
<a href="/agentik/widget.html#agentikShare=${id}">Открыть копию чата</a>
</main></body>
</html>`;
	return new Response(method === "HEAD" ? null : html, { headers: {
		...headers,
		"Content-Type": "text/html; charset=utf-8",
		"Content-Length": String(Buffer.byteLength(html)),
		"Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"
	} });
}
// server/telegram-shares.ts
var SHARE_DURATION_MS = 864e5;
var MAX_BODY_BYTES = 2097152;
var OWNER_METHODS = "GET, PUT, DELETE";
var PUBLIC_PREFIX = `${TELEGRAM_SHARE_PREFIX}/`;
var ShareBodyTooLarge = class extends Error {};
function parseSnapshot(value) {
	if (!value || typeof value !== "object") return null;
	const { title, messages } = value;
	if (typeof title !== "string" || !title.trim() || title.length > 100 || !Array.isArray(messages) || messages.length > 50) return null;
	const sanitized = [];
	for (const message of messages) {
		if (!message || typeof message !== "object") return null;
		const { author, text, role, hasImage } = message;
		if (typeof author !== "string" || !author.trim() || author.length > 100 || typeof text !== "string" || text.length > MAX_TELEGRAM_SHARE_TEXT_LENGTH || role !== "user" && role !== "assistant" || hasImage !== void 0 && typeof hasImage !== "boolean") return null;
		sanitized.push({
			author,
			text,
			role,
			...hasImage === void 0 ? {} : { hasImage }
		});
	}
	return {
		title,
		messages: sanitized
	};
}
async function readSnapshot(request) {
	if (Number(request.headers.get("Content-Length")) > MAX_BODY_BYTES) throw new ShareBodyTooLarge();
	const reader = request.body?.getReader();
	if (!reader) return null;
	const decoder = new TextDecoder("utf-8", { fatal: true });
	let size = 0;
	let json = "";
	try {
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			size += value.byteLength;
			if (size > MAX_BODY_BYTES) throw new ShareBodyTooLarge();
			json += decoder.decode(value, { stream: true });
		}
		const payload = JSON.parse(json + decoder.decode());
		const snapshot = parseSnapshot(payload);
		if (!snapshot) return null;
		const previewPng = parseSharePreviewPng(payload?.previewPng);
		if (payload?.previewPng !== void 0 && !previewPng) return null;
		return {
			snapshot,
			previewPng
		};
	} finally {
		reader.releaseLock();
	}
}
function telegramTarget({ botUsername, miniAppShortName }) {
	const bot = botUsername?.trim().replace(/^@/, "");
	const app = miniAppShortName?.trim();
	if (!bot || !/^[a-z0-9_]{5,32}$/i.test(bot) || app && !/^[a-z0-9_]{1,64}$/i.test(app)) return null;
	return app ? `https://t.me/${bot}/${app}` : `https://t.me/${bot}`;
}
async function replaceFile(temporary, destination) {
	for (let attempt = 0;; attempt++) try {
		await rename(temporary, destination);
		return;
	} catch (error) {
		const code = error.code;
		if (process.platform !== "win32" || attempt === 2 || code !== "EPERM" && code !== "EBUSY") throw error;
		await setTimeout(10 * (attempt + 1));
	}
}
function createStore(directory, now) {
	if (!directory) {
		const records = /* @__PURE__ */ new Map();
		return {
			async read(scope) {
				return records.get(scope) ?? null;
			},
			async write(scope, share) {
				const time = now();
				for (const [key, record] of records) if (record.link.expiresAt <= time) records.delete(key);
				records.set(scope, share);
			},
			async remove(scope) {
				records.delete(scope);
			}
		};
	}
	const root = resolve(directory);
	const pathFor = (scope) => join(root, `${scope}.json`);
	return {
		async read(scope) {
			try {
				const stored = JSON.parse(await readFile(pathFor(scope), "utf8"));
				const { id, url, expiresAt } = stored.link;
				const snapshot = parseSnapshot(stored.snapshot);
				if (!isTelegramShareId(id) || id.slice(2, 34) !== scope || typeof url !== "string" || !Number.isSafeInteger(expiresAt) || !snapshot) return null;
				return {
					link: {
						id,
						url,
						expiresAt
					},
					snapshot,
					previewPng: parseSharePreviewPng(stored.previewPng)
				};
			} catch (error) {
				if (error.code === "ENOENT" || error instanceof SyntaxError) return null;
				throw error;
			}
		},
		async write(scope, share) {
			await mkdir(root, {
				recursive: true,
				mode: 448
			});
			const temporary = join(root, `${share.link.id}.tmp`);
			const file = await open(temporary, "wx", 384);
			try {
				try {
					await file.writeFile(JSON.stringify(share), "utf8");
					await file.sync();
				} finally {
					await file.close();
				}
				await replaceFile(temporary, pathFor(scope));
			} catch (error) {
				await rm(temporary, { force: true }).catch(() => {});
				throw error;
			}
		},
		async remove(scope) {
			await rm(pathFor(scope), { force: true });
		}
	};
}
function createTelegramShares(options) {
	const now = options.now ?? Date.now;
	const target = telegramTarget(options);
	const publicOrigin = httpsShareOrigin(options.publicOrigin);
	const pagePrefix = TELEGRAM_SHARE_PAGE_PREFIX + "/";
	const store = createStore(options.directory, now);
	async function current(scope) {
		const record = await store.read(scope);
		return record && record.link.expiresAt > now() ? record : null;
	}
	async function readPublic(id) {
		if (!isTelegramShareId(id)) return null;
		const record = await current(id.slice(2, 34));
		return record && timingSafeEqual(Buffer.from(id), Buffer.from(record.link.id)) ? record : null;
	}
	function publicLink(link) {
		return publicOrigin ? {
			...link,
			previewUrl: publicOrigin + pagePrefix + link.id
		} : link;
	}
	return async (request, session, baseHeaders) => {
		const headers = {
			...baseHeaders,
			"Cache-Control": "no-store",
			"Referrer-Policy": "no-referrer",
			"X-Robots-Tag": "noindex"
		};
		const out = (status, data, extra) => Response.json(data, {
			status,
			headers: {
				...headers,
				...extra
			}
		});
		const notFound = () => out(404, { error: "Ссылка недоступна." });
		const url = new URL(request.url);
		const method = request.method;
		try {
			if (url.pathname.startsWith(pagePrefix)) {
				if (!publicOrigin) return notFound();
				const [id, filename, extra] = url.pathname.slice(pagePrefix.length).split("/");
				if (!isTelegramShareId(id) || extra !== void 0 || filename !== void 0 && filename !== "preview.png") return notFound();
				if (method !== "GET" && method !== "HEAD") return out(405, { error: "Используйте GET или HEAD." }, { Allow: "GET, HEAD" });
				const record = await readPublic(id);
				if (!record) return notFound();
				return respondToSharePreview({
					method,
					headers,
					title: record.snapshot.title,
					id,
					publicOrigin,
					previewPng: record.previewPng,
					image: filename === "preview.png"
				});
			}
			if (url.pathname !== "/api/telegram/shares") {
				const id = url.pathname.slice(PUBLIC_PREFIX.length);
				if (!url.pathname.startsWith(PUBLIC_PREFIX) || !isTelegramShareId(id)) return notFound();
				if (method !== "GET") return out(405, { error: "Используйте GET." }, { Allow: "GET" });
				const record = await readPublic(id);
				if (!record) return notFound();
				return out(200, {
					...record.snapshot,
					expiresAt: record.link.expiresAt
				});
			}
			if (!session) return out(401, { error: "Войдите по коду доступа." });
			if (method !== "GET" && method !== "PUT" && method !== "DELETE") return out(405, { error: "Используйте GET, PUT или DELETE." }, { Allow: OWNER_METHODS });
			const sources = url.searchParams.getAll("source");
			const [source] = sources;
			if (sources.length !== 1 || !/^(?:chat|room):[^\x00-\x1f\x7f]{1,128}$/.test(source) || /[\x00-\x1f\x7f]/.test(source)) return out(400, { error: "Укажите чат." });
			const scope = createHash("sha256").update(JSON.stringify([session.accountId, source])).digest("hex").slice(0, 32);
			if (method === "GET") {
				const active = await current(scope);
				return out(200, { share: active ? publicLink(active.link) : null });
			}
			if (method === "DELETE") {
				await store.remove(scope);
				return new Response(null, {
					status: 204,
					headers
				});
			}
			if (!target) return out(503, { error: "Telegram ещё не подключён." });
			if (request.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() !== "application/json") return out(415, { error: "Ожидается JSON." });
			let publication;
			try {
				publication = await readSnapshot(request);
			} catch (error) {
				if (error instanceof ShareBodyTooLarge) return out(413, { error: "Запрос слишком большой." });
				return out(400, { error: "Некорректный JSON." });
			}
			if (!publication) return out(400, { error: "Проверьте историю чата." });
			const id = `s_${scope}_${randomBytes(18).toString("base64url")}`;
			const query = new URLSearchParams({
				startapp: id,
				mode: "compact"
			});
			const link = {
				id,
				url: `${target}?${query}`,
				expiresAt: now() + SHARE_DURATION_MS
			};
			await store.write(scope, {
				link,
				...publication
			});
			return out(200, { share: publicLink(link) });
		} catch {
			return out(503, { error: "Публикация в Telegram временно недоступна." });
		}
	};
}
// server/telegram-mini-app.ts
var base = "/agentik/";
var files = await realpath(fileURLToPath(new URL("./dist/", import.meta.url)));
var port = Number(process.env.PORT || 3001);
var host = process.env.HOST || "127.0.0.1";
var telegram = createTelegramShares({
	directory: resolve(process.env.TELEGRAM_SHARE_DIR || "data/telegram-shares"),
	botUsername: process.env.TELEGRAM_BOT_USERNAME,
	miniAppShortName: process.env.TELEGRAM_MINI_APP_SHORT_NAME,
	publicOrigin: process.env.ALLOWED_ORIGIN?.split(",").map((origin) => origin.trim()).find((origin) => origin.startsWith("https://"))
});
var api = nodeApi(createRuntime(process.env, port, telegram));
var contentTypes = {
	".html": "text/html; charset=utf-8",
	".js": "text/javascript; charset=utf-8",
	".mjs": "text/javascript; charset=utf-8",
	".css": "text/css; charset=utf-8",
	".svg": "image/svg+xml",
	".woff2": "font/woff2",
	".png": "image/png"
};
function inside(root, path) {
	const pathFromRoot = relative(root, path);
	return pathFromRoot && pathFromRoot !== ".." && !pathFromRoot.startsWith(".." + sep) && !isAbsolute(pathFromRoot);
}
async function respond(request, response) {
	const path = new URL(request.url ?? "/", "http://localhost").pathname;
	if (path.startsWith("/api/") || path.startsWith("/agentik/share/")) return api(request, response);
	if (request.method !== "GET" && request.method !== "HEAD") {
		response.writeHead(405, { Allow: "GET, HEAD" }).end();
		return;
	}
	if (path === "/" || path === "/agentik") {
		response.writeHead(308, { Location: base }).end();
		return;
	}
	let file;
	let size = 0;
	try {
		if (path.startsWith(base)) {
			const name = decodeURIComponent(path.slice(9)) || "index.html";
			const candidate = resolve(files, name);
			if (inside(files, candidate)) {
				const actual = await realpath(candidate);
				const info = inside(files, actual) ? await stat(actual) : null;
				if (info?.isFile()) {
					file = actual;
					size = info.size;
				}
			}
		}
	} catch {}
	if (!file) {
		response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }).end("Страница не найдена.");
		return;
	}
	response.writeHead(200, {
		"Content-Type": contentTypes[extname(file)] ?? "application/octet-stream",
		"Content-Length": size,
		"Cache-Control": path.startsWith(base + "assets/") ? "public, max-age=31536000, immutable" : "no-cache",
		"X-Content-Type-Options": "nosniff",
		"Referrer-Policy": "no-referrer"
	});
	if (request.method === "HEAD") response.end();
	else createReadStream(file).on("error", () => response.destroy()).pipe(response);
}
var server = createServer((request, response) => {
	respond(request, response).catch(() => {
		if (response.headersSent) response.destroy();
		else response.writeHead(500, { "Cache-Control": "no-store" }).end();
	});
});
server.requestTimeout = 45e3;
server.headersTimeout = 1e4;
server.listen(port, host, () => console.log(`Agentik Mini App listens on http://${host}:${port}${base}`));
export {};
